# Day 2 production workflow

This repository is self-contained: the selected character art, barn drawing, narration audio, renderer, captions, and generated storyboard PNGs are included.

## Rebuild the video

1. Install the packages in `requirements.txt` with Python 3.10 or newer.
2. Keep the 1.25× narration at `assets/voiceover_1_25x.mp3`.
3. Run `python make_day2_video.py` from this directory.
4. The script writes `Farm_Survival_Day2_FarmScene.mp4`, `Farm_Survival_Day2_FarmScene.srt`, and `scenes/scene_01.png` through `scene_10.png`. `silent.mp4` is only an intermediate file.

## Narration workflow used

- The complete Day 2 script was generated as voiceover using the selected alternative voice.
- The original-speed recording is saved as `assets/voiceover_voice01_original.mp3`.
- The final recording was sped up with FFmpeg's `atempo=1.25` filter and saved as `assets/voiceover_1_25x.mp3`.
- The renderer delays the audio by 1.80 seconds to match the opening title and captions, then pads the ending through the final fire-wait scene.

## Art and animation notes

- E is the selected SHAREit red-pepper character, built from the included transparent PNG parts and static mouth/expression overlays. There is no lip-sync.
- The barn PNG is the supplied doodle reference. The well, path, wet ground, broken fence, dry wood, and fire-pot are drawn in the renderer to follow the written layout.
- `scenes/` contains the final vertical storyboard stills. `assets/` contains the character/scene PNG inputs used to render them.
