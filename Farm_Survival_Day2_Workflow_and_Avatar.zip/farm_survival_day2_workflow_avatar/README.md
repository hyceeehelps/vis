# Farm Survival — Day 2

A vertical continuation of the farm-scene short, built in the established hand-drawn farm layout.

## Deliverables

- `Farm_Survival_Day2_FarmScene.mp4` — 31.5-second H.264/AAC video, 720×1280 (9:16), 24 fps. Narration and burned-in captions are included.
- `Farm_Survival_Day2_FarmScene.srt` — editable caption timings; narration begins at 1.80 seconds.
- `make_day2_video.py` — renderer/source.
- `scenes/scene_01.png`–`scene_10.png` — storyboard stills used for the panels and fire-wait hold.
- `assets/` — selected E character layers, user-supplied barn doodle, original voice-01 narration, and the 1.25× Day 2 voiceover (20.30 seconds).

## Scene and performance notes

E remains the SHAREit red-pepper character and the foreground focus. E faces the camera with a visible, closed mouth; the narration is voiceover only, with no lip-sync or direct-to-camera speech. The farm keeps the barn on the left, the well on the right, and the dirt path centered. Day 2 adds the storm aftermath, broken fence, cloudy water, dry wood, and small fire with a pot.

The Day 2 narration uses the selected alternative voice and is sped to 1.25×. The supplied visual reference was the barn illustration; the well and path are drawn to match the written composition.

## Rebuild

From this directory, run:

```bash
python make_day2_video.py
```

The renderer uses Python with Pillow, NumPy, OpenCV, and `imageio-ffmpeg`. It writes the MP4, SRT, and storyboard PNGs into this project directory. The intermediate `silent.mp4` is regenerated during rendering.


## Avatar source kit

The `avatar_source/E_assets/` folder contains the selected E avatar PNG kit: full-body references, separated limbs/body/stem, facial and mouth overlays, anchor templates, previews, and the anchor map. The `assets/` folder holds the exact E PNG layers used by the Day 2 renderer.
