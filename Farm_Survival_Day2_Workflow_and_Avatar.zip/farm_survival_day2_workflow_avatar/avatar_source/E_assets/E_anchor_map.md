# E rig anchor map

Canvas: 1280 × 832 px. Coordinates start at the upper-left corner; x increases right and y increases down. The anchor locations follow the supplied sample.

| Anchor | Screen location | Center (x, y) |
|---|---|---:|
| `eye_screen_left` | Eye/expression anchor — screen left | (585, 298) |
| `eye_screen_right` | Eye/expression anchor — screen right | (686, 297) |
| `mouth_center` | Mouth anchor | (634, 370) |
| `arm_screen_left` | Arm/shoulder connection — screen left | (527, 396) |
| `arm_screen_right` | Arm/shoulder connection — screen right | (758, 397) |
| `leg_screen_left` | Leg/hip connection — screen left | (594, 632) |
| `leg_screen_right` | Leg/hip connection — screen right | (686, 583) |

All seven markers use the same white fill and dark outline. `E_anchor_base_no_markers.png` is the body + stem only; `E_anchor_markers.png` is the transparent marker overlay; `E_rig_anchor_template.png` combines both on a transparent canvas; `E_rig_anchor_template_white.png` is the white-background preview.

Use the arm and leg circles as connection centers and overlap the limb artwork slightly behind the body edge to avoid gaps. The eye circles indicate face/expression placement, and the mouth circle is the mouth center.
