# E starter PNG parts

All component PNGs have transparent backgrounds and share the same 1280×832 canvas for alignment. The source is the selected flattened E reference, not a layered original.

## Layer order (back to front)
1. `E_leg_left.png`, `E_leg_right.png`
2. `E_arm_left.png`, `E_arm_right.png`
3. `E_body_no_face.png`
4. `E_stem.png`
5. Choose one expression overlay: `E_face_angry.png`, `E_face_neutral.png`, `E_face_happy.png`, `E_face_surprised.png`, or `E_face_sad.png`
6. Optional: add one mouth overlay (`E_mouth_closed.png`, `E_mouth_A.png`, `E_mouth_E.png`, `E_mouth_O.png`, `E_mouth_MFV.png`, `E_mouth_smile.png`, or `E_mouth_frown.png`). For the original no-mouth look, omit the mouth layer.

## Anchor guide (based on the supplied sample)
- `E_anchor_base_no_markers.png` — pepper body + stem, no face/limbs/markers, transparent background.
- `E_anchor_markers.png` — seven consistent eye, mouth, arm, and leg circles on a transparent overlay.
- `E_rig_anchor_template.png` — combined transparent anchor template.
- `E_rig_anchor_template_white.png` — same guide on white, matching the sample.
- `E_anchor_map.md` — anchor names and pixel centers.

`E_stack_preview.png` shows the default angry-face stack. `E_full_transparent.png` is the complete character with the default face. `E_full_body_no_face.png` is the full-body transparent composite with facial features removed.

These are starter extractions/recreated overlays from the flattened AI reference; inspect and clean edges or adjust facial vectors before final publishing. The limb PNGs are whole arm/leg pieces (not elbow/knee-rigged). Keep a layered PSD/AI/other source master if continuing the puppet rig.
